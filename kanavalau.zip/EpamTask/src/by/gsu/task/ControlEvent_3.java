package by.gsu.task;

public class ControlEvent_3 {
    private boolean test_1;
    private boolean test_2;
    private boolean test_3;
    private boolean test_4;
    private boolean test_5;
    private boolean result;

    public ControlEvent_3(boolean test_1, boolean test_2, boolean test_3, boolean test_4, boolean test_5) {
        this.test_1 = test_1;
        this.test_2 = test_2;
        this.test_3 = test_3;
        this.test_4 = test_4;
        this.test_5 = test_5;
        this.result = result(test_1, test_2, test_3, test_4, test_5);
    }

    public boolean isTest_1() {
        return test_1;
    }

    public boolean isTest_2() {
        return test_2;
    }

    public boolean isTest_3() {
        return test_3;
    }

    public boolean isTest_4() {
        return test_4;
    }

    public boolean isTest_5() {
        return test_5;
    }

    public boolean isResult() {
        return result;
    }

    private boolean result(boolean test_1, boolean test_2, boolean test_3, boolean test_4, boolean test_5) {
        int count = 0;
        if (test_1)
            count++;
        if (test_2)
            count++;
        if (test_3)
            count++;
        if (test_4)
            count++;
        if (test_5)
            count++;
        return count >= 4;
    }

    @Override
    public String toString() {
        String t1 = isTest_1() ? "зач." : "не зач.";
        String t2 = isTest_2() ? "зач." : "не зач.";
        String t3 = isTest_3() ? "зач." : "не зач.";
        String t4 = isTest_4() ? "зач." : "не зач.";
        String t5 = isTest_5() ? "зач." : "не зач.";
        String res = isResult() ? "зач." : "не зач.";
        return String.format("зачет_1 = %-10s зачет_2 = %-10s зачет_3 = %-10s зачет_4 = " +
                "%-10s зачет_5 = %-10s результат - %s", t1, t2, t3, t4, t5, res);
    }
}
