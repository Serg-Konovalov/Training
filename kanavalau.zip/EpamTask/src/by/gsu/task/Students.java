package by.gsu.task;

public class Students {
    private String name;
    private ControlEvent_1 controlEvent_1;
    private ControlEvent_2 controlEvent_2;
    private ControlEvent_3 controlEvent_3;

    public Students(String name, ControlEvent_1 controlEvent_1, ControlEvent_2 controlEvent_2, ControlEvent_3 controlEvent_3) {
        this.name = name;
        this.controlEvent_1 = controlEvent_1;
        this.controlEvent_2 = controlEvent_2;
        this.controlEvent_3 = controlEvent_3;
    }

    public String getName() {
        return name;
    }

    public ControlEvent_1 getControlEvent_1() {
        return controlEvent_1;
    }

    public ControlEvent_2 getControlEvent_2() {
        return controlEvent_2;
    }

    public ControlEvent_3 getControlEvent_3() {
        return controlEvent_3;
    }

    @Override
    public String toString() {
        return String.format("%-35s", getName());
    }
}
