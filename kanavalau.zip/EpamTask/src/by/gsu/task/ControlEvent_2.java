package by.gsu.task;

public class ControlEvent_2 {
    private double exam;
    private boolean test;
    private boolean result;

    public ControlEvent_2(double exam, boolean test) {
        this.exam = exam;
        this.test = test;
        this.result = result(exam, test);
    }

    public double getExam() {
        return exam;
    }

    public boolean isTest() {
        return test;
    }

    public boolean isResult() {
        return result;
    }

    private boolean result(double exam, boolean test) {
        return exam >= 6 && test;
    }

    @Override
    public String toString() {
        String t1 = isTest() ? "зач." : "не зач.";
        String res = isResult() ? "зач." : "не зач.";
        return String.format("экзамен_1 = %-10.1f зачет_1 = %-10s результат - %s", getExam(), t1, res);
    }
}
