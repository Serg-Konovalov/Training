package by.gsu.task;

import java.util.List;

public class OutputResults {
    public static void printUnSorted(List<Students> studentsList) {
        System.out.println("\nНЕСОРТИРОВАННЫЕ РЕЗУЛЬТАТЫ");

        System.out.println("\nКонтрольное мероприятие 1");
        for (Students students : studentsList) {
            System.out.println(students + ": " + students.getControlEvent_1());
        }

        System.out.println("\nКонтрольное мероприятие 2");
        for (Students students : studentsList) {
            System.out.println(students + ": " + students.getControlEvent_2());
        }

        System.out.println("\nКонтрольное мероприятие 3");
        for (Students students : studentsList) {
            System.out.println(students + ": " + students.getControlEvent_3());
        }
    }

    public static void printSorted(List<Students> studentsList) {
        System.out.println("\nСОРТИРОВАННЫЕ РЕЗУЛЬТАТЫ");
        System.out.println("\nКонтрольное мероприятие 1 зачтено");
        for (Students students : studentsList) {
            if (students.getControlEvent_1().isResult()) {
                System.out.println(students + ": " + students.getControlEvent_1());
            }
        }

        System.out.println("\nКонтрольное мероприятие 1 не зачтено");
        for (Students students : studentsList) {
            if (!students.getControlEvent_1().isResult()) {
                System.out.println(students + ": " + students.getControlEvent_1());
            }
        }

        System.out.println("\nКонтрольное мероприятие 2 зачтено");
        for (Students students : studentsList) {
            if (students.getControlEvent_2().isResult()) {
                System.out.println(students + ": " + students.getControlEvent_2());
            }
        }

        System.out.println("\nКонтрольное мероприятие 2 не зачтено");
        for (Students students : studentsList) {
            if (!students.getControlEvent_2().isResult()) {
                System.out.println(students + ": " + students.getControlEvent_2());
            }
        }

        System.out.println("\nКонтрольное мероприятие 3 зачтено");
        for (Students students : studentsList) {
            if (students.getControlEvent_3().isResult()) {
                System.out.println(students + ": " + students.getControlEvent_3());
            }
        }

        System.out.println("\nКонтрольное мероприятие 3 не зачтено");
        for (Students students : studentsList) {
            if (!students.getControlEvent_3().isResult()) {
                System.out.println(students + ": " + students.getControlEvent_3());
            }
        }
    }
}
