package by.gsu.task;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Parser {
    public static List<String> readFile(String fileName) {
        List<String> stringList = new ArrayList<>();
        try {
            stringList = Files.lines(Paths.get(fileName), StandardCharsets.UTF_8).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringList;
    }

    public static List<Students> pars(List<String> stringList) {
        List<Students> studentsList = new ArrayList<>();

        for (String s : stringList) {
            String[] pars = s.split(";");
            String[] value = new String[pars.length];
            value[0] = pars[0];

            for (int i = 1; i < pars.length; i++) {
                value[i] = pars[i].substring(pars[i].indexOf('_') + 1);
            }

            String name = value[0];
            int ev1ex1 = Integer.parseInt(value[1]);
            int ev1ex2 = Integer.parseInt(value[2]);
            ControlEvent_1 ev1 = new ControlEvent_1(ev1ex1, ev1ex2);

            double ev2ex1 = Double.parseDouble(value[3]);
            boolean ev2test1 = value[4].equals("зач");
            ControlEvent_2 ev2 = new ControlEvent_2(ev2ex1, ev2test1);

            boolean ev3test1 = value[5].equals("зач");
            boolean ev3test2 = value[6].equals("зач");
            boolean ev3test3 = value[7].equals("зач");
            boolean ev3test4 = value[8].equals("зач");
            boolean ev3test5 = value[9].equals("зач");
            ControlEvent_3 ev3 = new ControlEvent_3(ev3test1, ev3test2, ev3test3, ev3test4, ev3test5);

            Students students = new Students(name, ev1, ev2, ev3);
            studentsList.add(students);
        }
        return studentsList;
    }
}
