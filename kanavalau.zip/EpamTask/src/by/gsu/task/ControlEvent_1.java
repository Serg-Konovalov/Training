package by.gsu.task;

public class ControlEvent_1 {
    private int exam_1;
    private int exam_2;
    private boolean result;

    public ControlEvent_1(int exam_1, int exam_2) {
        this.exam_1 = exam_1;
        this.exam_2 = exam_2;
        this.result = result(exam_1, exam_2);
    }

    public int getExam_1() {
        return exam_1;
    }

    public int getExam_2() {
        return exam_2;
    }

    public boolean isResult() {
        return result;
    }

    private boolean result(int exam_1, int exam_2) {
        return (exam_1 + exam_2) >= 12;
    }

    @Override
    public String toString() {
        String res = ((isResult()) ? "зач." : "не зач.");
        return String.format("экзамен_1 = %-10d экзамен_2 = %-10d результат - %s", getExam_1(), getExam_2(), res);
    }
}
