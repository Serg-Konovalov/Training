package by.gsu.task;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println("Введите имя файла с расширением:\n");
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in))) {
            String fileName = bufferedReader.readLine();
            List<Students> studentsList = Parser.pars(Parser.readFile(fileName));
            OutputResults.printUnSorted(studentsList);
            OutputResults.printSorted(studentsList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
